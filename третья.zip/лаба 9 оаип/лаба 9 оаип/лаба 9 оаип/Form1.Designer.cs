﻿namespace лаба_9_оаип
{
    partial class FormForPolishNotation
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBoxRectangle = new PictureBox();
            groupBoxPolish = new GroupBox();
            labelInstruction = new Label();
            listBoxForComands = new ListBox();
            textBoxForCommand = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBoxRectangle).BeginInit();
            groupBoxPolish.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBoxRectangle
            // 
            pictureBoxRectangle.BackColor = SystemColors.MenuBar;
            pictureBoxRectangle.Location = new Point(12, 12);
            pictureBoxRectangle.Name = "pictureBoxRectangle";
            pictureBoxRectangle.Size = new Size(599, 547);
            pictureBoxRectangle.TabIndex = 0;
            pictureBoxRectangle.TabStop = false;
            // 
            // groupBoxPolish
            // 
            groupBoxPolish.BackColor = Color.RosyBrown;
            groupBoxPolish.Controls.Add(labelInstruction);
            groupBoxPolish.Controls.Add(listBoxForComands);
            groupBoxPolish.Controls.Add(textBoxForCommand);
            groupBoxPolish.Location = new Point(617, 12);
            groupBoxPolish.Name = "groupBoxPolish";
            groupBoxPolish.Size = new Size(431, 547);
            groupBoxPolish.TabIndex = 1;
            groupBoxPolish.TabStop = false;
            groupBoxPolish.Text = "опззз";
            // 
            // labelInstruction
            // 
            labelInstruction.AutoSize = true;
            labelInstruction.FlatStyle = FlatStyle.Flat;
            labelInstruction.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelInstruction.Location = new Point(16, 36);
            labelInstruction.Name = "labelInstruction";
            labelInstruction.Size = new Size(357, 80);
            labelInstruction.TabIndex = 2;
            labelInstruction.Text = " Комманды для входной строки имеют формат\r\n  -Создание прямоугольника: x.y.w.h.name.R \r\n  -Перемещение прямоугольника: dx.dy.name.M \r\n  -Удаление прямоугольника: name.D";
            // 
            // listBoxForComands
            // 
            listBoxForComands.BackColor = SystemColors.MenuBar;
            listBoxForComands.FormattingEnabled = true;
            listBoxForComands.Location = new Point(16, 173);
            listBoxForComands.Name = "listBoxForComands";
            listBoxForComands.Size = new Size(409, 364);
            listBoxForComands.TabIndex = 1;
            // 
            // textBoxForCommand
            // 
            textBoxForCommand.Location = new Point(16, 140);
            textBoxForCommand.Name = "textBoxForCommand";
            textBoxForCommand.Size = new Size(409, 27);
            textBoxForCommand.TabIndex = 0;
            textBoxForCommand.KeyDown += textBox1_KeyDown;
            // 
            // FormForPolishNotation
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLightLight;
            ClientSize = new Size(1060, 571);
            Controls.Add(groupBoxPolish);
            Controls.Add(pictureBoxRectangle);
            Name = "FormForPolishNotation";
            Text = "polishNotationFigure";
            ((System.ComponentModel.ISupportInitialize)pictureBoxRectangle).EndInit();
            groupBoxPolish.ResumeLayout(false);
            groupBoxPolish.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBoxRectangle;
        private GroupBox groupBoxPolish;
        private ListBox listBoxForComands;
        private TextBox textBoxForCommand;
        private Label labelInstruction;
    }
}
